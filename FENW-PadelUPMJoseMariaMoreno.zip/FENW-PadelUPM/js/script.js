
$('#mainNav').affix({
    offset: {
        top: 100
    }
})

$('#servicios').click(function(){
    $('html, body').animate({
        scrollTop: $('#divServices').offset().top+ (-120)
    }, 1200);
    return false;
});

$('#instalaciones').click(function(){
    $('html, body').animate({
        scrollTop: $('#divInstalaciones').offset().top+ (-120)
    }, 1200);
    return false;
});

$('#contacto').click(function(){
    $('html, body').animate({
        scrollTop: $('#divContacto').offset().top+ (-120)
    }, 1200);
    return false;
});

$('#logo').click(function(){
    $("html, body").animate({ scrollTop: 0 }, 1200);
    return false;

});


$("#clases")
    .mouseenter(function() {
        $("#img-clases").animate({opacity:0.25});
        $("#msg-clases").show();

    })
    .mouseleave(function() {
        $("#img-clases").animate({opacity:.5});
        $("#msg-clases").hide();
    });


$("#entrenamientos")
    .mouseenter(function () {
        $("#img-entrenamientos").animate({opacity:.25});
        $("#msg-entrenamientos").show();
    })
    .mouseleave(function() {
        $("#img-entrenamientos").animate({opacity:.5});
        $("#msg-entrenamientos").hide();
    });

$("#campeonatos")
    .mouseenter(function () {
        $("#img-campeonatos").animate({opacity:.25});
        $("#msg-campeonatos").show();
    })
    .mouseleave(function() {
        $("#img-campeonatos").animate({opacity:.5});
        $("#msg-campeonatos").hide();
    });

$("#fecha").birthdayPicker();


